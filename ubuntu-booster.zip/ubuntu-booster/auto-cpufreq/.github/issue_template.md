### Error output:
```text
Paste here error output
```
---

### System information:
```text
Paste here output of the auto-cpufreq --debug
```
---
