Donate :)
Support us in Bitcoin:

bc1ql49pjc20jpddgkr0vn8xssefmt24tkjr00f0kd

# This tool will download,install and optimize
# a concept of software and settings.
# Its purpose is to optimize the system and make it
# work much faster while maintaining stability.

# Warning !!
# The installation is intended only for distributions based
# on Ubuntu LTS 20.04 and immediately after installing a new and clean system.
# Installation on old systems may overwrite existing settings.
# For this reason it is required to make a full backup of
# old systems before installation! 


Installation process....

Copy the tool to home folder 


Open a terminal and run the following command

###########################
sudo apt-get install git -y
###########################

##################################################### 
cd ubuntu-booster && sudo ./install_ubuntu_booster.sh
#####################################################

or

You do not have copy to your home folder.
You can simply move it to any folder you want and run it by
the following commands 

################################
cd ubuntu-booster
********************************
sudo ./install_ubuntu_booster.sh
################################


###################################################################
You have two options
1. Install with the excellent liquorix kernel
2. You can install with the default kernel of Ubuntu distributions

It is possible to back up important files 

You will always have the option to use the tool
Grub Customizer which is also installed
To replace kernel 
##################################################################

Feel the power of Linux 

Enjoy! 




