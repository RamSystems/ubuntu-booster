#!/bin/bash

    mkdir /home/beckup_ubuntu_super_booster/

    sudo cp  '/etc/sysctl.conf' '/home/beckup_ubuntu_super_booster/'
    sudo cp '/etc/default/grub' '/home/beckup_ubuntu_super_booster/'
    sudo cp '/etc/hdparm.conf' '/home/beckup_ubuntu_super_booster/'





